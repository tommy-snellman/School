package view;
import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.MouseInputListener;

import model.ClientModel;
import model.Model;
import model.Stock;

@SuppressWarnings("serial")
class ClientGraphPanel extends JPanel {
	
	public Stock stock1, stock2;
	private int mouseX, mouseY;
	private boolean inside;
	public ClientModel model;
	
	ClientGraphPanel(ClientModel model) {
		super();
		this.model = model;
		MouseTracker2 m = new MouseTracker2(this);
		this.addMouseMotionListener(m);
		this.addMouseListener(m);
	}
	
	public void paintComponent( Graphics g ) {
		super.paintComponent(g);
		
		int width = this.getWidth();
		int height = this.getHeight();
		if (stock1 != null && stock2 != null && stock1.isReady() && stock2.isReady()){
			double s1Min = stock1.getMin();
			double s1Max = stock1.getMax();
			double s2Min = stock2.getMin();
			double s2Max = stock2.getMax();
			double min, max;
			if (s1Min < s2Min) min = s1Min;
			else min = s2Min;
			
			if (s1Max > s2Max) max = s1Max;
			else max = s2Max;
			
			int fontSize = 15;
			
			g.setFont(new Font("Test", Font.BOLD, fontSize));
			g.setColor(Color.red);
			int size = stock1.getSize() - 1;
			for (int i = 0; i < size; i++){
				g.drawLine(map(i, 0, size, 0, width), map(stock1.getCloneClose(i), max, min, 0, height), map(i+1, 0, size, 0, width), map(stock1.getCloneClose(i + 1), max, min, 0, height));
			}
			g.drawString(String.format(stock1.getTicker() + " max close: %.2f", s1Max), 2, 12);
			g.drawString(String.format(stock1.getTicker() + " min close: %.2f", s1Min), 2, height - 12);
			g.setColor(Color.green);
			
			for (int i = 0; i < size; i++){
				g.drawLine(map(i, 0, size, 0, width), map(stock2.getCloneClose(i), max, min, 0, height), map(i+1, 0, size, 0, width), map(stock2.getCloneClose(i + 1), max, min, 0, height));
			}
			
			g.drawString(String.format(stock2.getTicker() + " max close: %.2f", s2Max), 2, 28);
			g.drawString(String.format(stock2.getTicker() + " min close: %.2f", s2Min), 2, height - 28);
			
			g.setColor(Color.BLACK);
			g.drawString(String.format("Correlation: %.4f", model.getCorrelation()), width-190, 20);
			
			if (inside) {
				int index = map(mouseX, 0, width, 0, size);
				int mX = mouseX + 10;
				int mY = mouseY - 20;
				if (mouseX > width-200) mX = mouseX - 200;
				else mX = mouseX + 10;
				
				g.setColor(Color.BLACK);
				g.drawLine(mouseX, 0, mouseX, height);
				g.setFont(new Font("Teest", Font.PLAIN, fontSize));
				g.drawString(stock1.getTicker()+ String.format(" close: %.2f (%.2f%%)", stock1.getClose(index), stock1.procent(index)), mX, mY);
				g.drawString(String.format("high: %.2f", stock1.getHigh(index)), mX, mY+fontSize);
				g.drawString(String.format("low: %.2f", stock1.getLow(index)), mX, mY+fontSize*2);
				g.drawString(stock2.getTicker()+ String.format(" close: %.2f (%.2f%%)", stock2.getClose(index), stock2.procent(index)), mX, mY+fontSize*4);
				g.drawString(String.format("high: %.2f", stock2.getHigh(index)), mX, mY+fontSize*5);
				g.drawString(String.format("low: %.2f", stock2.getLow(index)), mX, mY+fontSize*6);
			}
		}
	}
	
	public double norm(double value, double min, double max) {
		return (value - min) / (max - min);
	}
	
	public double lerp(double norm, int min, int max){
		return (max - min) * norm + min;
	}
	
	public int map(double value, double sourceMin, double sourceMax, int destMin, int destMax){

		return (int)lerp(norm(value, sourceMin, sourceMax), destMin, destMax);
	}

	
	public void setPos(int x, int y) {
		mouseX = x;
		mouseY = y;
		repaint();
	}
	
	public void setInside(boolean in) {
		inside = in;
		repaint();
	}
	
	

}

@SuppressWarnings("serial")
class MouseTracker2 extends JComponent implements MouseListener, MouseMotionListener {
	
	int mouseX;
	int mouseY;
	ClientGraphPanel panel;
	
	MouseTracker2 () {
		enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);
		addMouseListener(this);
	}
	
	MouseTracker2(ClientGraphPanel p) {
		panel = p;
		enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);
		addMouseListener(this);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		panel.setInside(false);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		panel.setInside(true);
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		panel.setPos(e.getX(), e.getY());
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		panel.setPos(e.getX(), e.getY());
	}

	
	
}