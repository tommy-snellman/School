package stockProgram;

import javax.swing.SwingUtilities;

import controller.ClientController;
import controller.Controller;
import model.ClientModel;
import model.Model;
import view.ClientView;
import view.View;

public class ClientApplication {

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				runApp();
				
			}
		});
	}
	
	public static void runApp() {
		ClientModel model = new ClientModel();
		ClientView view = new ClientView(model);
		ClientController controller = new ClientController(view, model);
		
		
		view.setSearchListener(controller);
	}
}
