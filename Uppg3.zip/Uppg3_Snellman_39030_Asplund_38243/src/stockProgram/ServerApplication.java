package stockProgram;

import javax.swing.SwingUtilities;

import controller.Controller;
import controller.ServerController;
import model.Model;
import view.View;

public class ServerApplication {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				runApp();
				
			}
		});
	}
	
	public static void runApp() {
		Model model = new Model();
		ServerController controller = new ServerController(model);
		
		while (true) {
			controller.run();
		}
	}
}
