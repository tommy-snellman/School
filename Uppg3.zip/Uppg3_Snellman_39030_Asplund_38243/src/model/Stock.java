package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import javax.swing.JOptionPane;

public class Stock {
	private String ticker;
	private String url;
	private ArrayList<Node> data = new ArrayList<>();
	private ArrayList<Node> clone;
	// String[]
	// 0 = date, 1 = open, 2 = high, 3 = low, 4 = close, 5 = volume, 6 = adj
	// close
	private double currentPrice;
	private String start;
	private String end;
	private boolean ready;

	public Stock(String ticker, String start, String end) {
		this.ticker = ticker;
		this.start = start;
		this.end = end;
		makeUrl(start, end);
	}

	private void makeUrl(String sD, String eD) {
		try {
			String dt = sD + "." + eD;
			String[] dates = dt.split("\\.");
			int[] date = new int[6];
			for (int i = 0; i < dates.length; i++) {
				date[i] = Integer.parseInt(dates[i]);
			}
			date[1]--;
			date[4]--;
			for (int x = 0; x < date.length; x++) {
				dates[x] = String.valueOf(date[x]);
			}
			this.start = dates[0] + "." + dates[1] + "." + dates[2];
			this.end = dates[3] + "." + dates[4] + "." + dates[5];
			this.url = "http://ichart.finance.yahoo.com/table.csv?s=" + this.ticker + "&a=" + dates[1] + "&b="
					+ dates[0] + "&c=" + dates[2] + "&d=" + dates[4] + "&e=" + dates[3] + "&f=" + dates[5]
					+ "&g=d&ignore=.csv";
		} catch (ArrayIndexOutOfBoundsException e) {
			JOptionPane.showMessageDialog(null, "Felaktigt input, får ej vara tomt, försök igen!", "Felaktigt input",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void fetchData() {
		try {
			URL ul = new URL(this.url);
			BufferedReader reader = new BufferedReader(new InputStreamReader(ul.openStream()));
			String s;
			reader.readLine();
			while ((s = reader.readLine()) != null) {
				String[] tmp = s.split("\\,");
				data.add(new Node(tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6]));
			}
			Collections.reverse(data);
		} catch (MalformedURLException e) {

		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null,
					"Felaktigt input, försök igen!\nKontrollera" + " att tickers och/eller daturm är korrekt ifyllt!",
					"Felaktigt input", JOptionPane.ERROR_MESSAGE);
		} catch (ArrayIndexOutOfBoundsException e) {
			JOptionPane.showMessageDialog(null, "Felaktigt input, får ej vara tomt, försök igen!", "Felaktigt input",
					JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,
					"Felaktigt input, försök igen!\nKontrollera" + " att tickers och/eller daturm är korrekt ifyllt!",
					"Felaktigt input", JOptionPane.ERROR_MESSAGE);
		}
		setClone();
	}
	
	public void fetchMinuteData() {
		try {
			URL ul = new URL("http://chartapi.finance.yahoo.com/instrument/1.0/"+this.ticker+"/chartdata;type=quote;range=1d/csv");
			BufferedReader reader = new BufferedReader(new InputStreamReader(ul.openStream()));
			String s;
			for (int i = 0; i < 17; i++) {
				reader.readLine();
			}
			DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			while ((s = reader.readLine()) != null) {
				String[] tmp = s.split("\\,");
				int time = Integer.parseInt(tmp[0]);
				Date date = new Date(time*1000L);
				data.add(new Node(format.format(date), tmp[4], tmp[2], tmp[3], tmp[1], tmp[5], "0.0"));
			}
		} catch (IOException e) {
			System.out.println(e);	
		}
		setClone();
	}
	
	public void resetList() {
		data = new ArrayList<>();
	}
	
	public void addData(String date, String close) {
		data.add(new Node(date, "0", "0", "0", close, "0", "0"));
	}
	
	public Double procent(int i) {
		if (i == 0) {
			return 0.0;
		}
		return (getClose(i) / getClose(i-1) - 1) * 100;
	}

	public void setClone() {
		clone = new ArrayList<>(data.size());
		for (Node n : data) {
			clone.add(new Node(n.date, n.open, n.high, n.low, n.close, n.volume, n.adj_close));
		}
	}

	public String getTicker() {
		return this.ticker;
	}

	public int getSize() {
		return this.data.size();
	}

	public String getStart() {
		return this.start;
	}
	
	public String getEnd() {
		return this.end;
	}
	
	public String getDate(int i) {
		return clone.get(i).date;
	}

	public Double getClose(int i) {
		return data.get(i).close;
	}
	
	public Double getHigh(int i) {
		return clone.get(i).high;
	}
	
	public Double getLow(int i) {
		return clone.get(i).low;
	}
	
	public Double getCloneClose(int i) {
		return clone.get(i).close;
	}
	
	public double getMax() {
		double max = 0;
		
		for (Node n : clone) {
			if (n.close > max) {
				max = n.close;
			}
		}
		return max;
	}
	
	public double getMin() {
		double min = clone.get(0).close;
		
		for (Node n : clone) {
			if (n.close < min) {
				min = n.close;
			}
		}
		return min;
	}
	
	public void setClose(int i, String s) {
		double tmp1 = this.data.get(i).close;
		double tmp2 = Double.parseDouble(s);
		tmp1 *= tmp2;
		this.clone.get(i).close = tmp1;
	}

	public Double getMean() {
		double sum = 0;
		for (int i = 0; i < getSize(); i++) {
			sum += getCloneClose(i);
		}
		
		double s = sum/(getSize());
		return s;
	}
	
	public double getStdDeviation() {
		double mean = getMean();
		double sum = 0;
		for (int i = 0; i < getSize(); i++) {
			sum += Math.pow((getCloneClose(i) - mean), 2);
		}
		
		sum /= getSize();
		double s = Math.sqrt(sum);
		return s;
	}

	public double getCurrPrice() {
		try {
			URL ul = new URL("http://finance.yahoo.com/d/quotes.csv?s="+this.ticker+"&f=l1");
			BufferedReader reader = new BufferedReader(new InputStreamReader(ul.openStream()));
			String s = reader.readLine();
			return Double.parseDouble(s);
		} catch (MalformedURLException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
		return 0;
	}
	
	public double getCurrSavedPrice() {
		return this.currentPrice;
	}
	
	public void setCurrPrice(double curr) {
		this.currentPrice = curr;
	}
	
	public void setMinuteData() {
		
	}

	public void setData() {
		
	}
	
	public boolean isReady() {
		return this.ready;
	}

	public void setReady(boolean b) {
		this.ready = b;
	}
	
	private class Node {
		private String date;
		private Double open;
		private Double high;
		private Double low;
		private Double close;
		private Double volume;
		private Double adj_close;

		private Node(String d, String o, String h, String l, String c, String v, String ac) {
			this.date = d;
			this.open = Double.parseDouble(o);
			this.high = Double.parseDouble(h);
			this.low = Double.parseDouble(l);
			this.close = Double.parseDouble(c);
			this.volume = Double.parseDouble(v);
			this.adj_close = Double.parseDouble(ac);
		}
		
		private Node(String d, double o, double h, double l, double c, double v, double ac) {
			this.date = d;
			this.open = o;
			this.high = h;
			this.low = l;
			this.close = c;
			this.volume = v;
			this.adj_close = ac;
		}
	}


}
