package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JOptionPane;

import model.ClientModel;
import model.Currency;
import model.Model;
import model.Stock;
import model.Subject;
import view.ClientView;
import view.CurrencyChangeEvent;
import view.CurrencyListener;
import view.CurrencySearchFormEvent;
import view.Observer;
import view.SearchFormEvent;
import view.SearchListener;
import view.View;

public class ClientController implements SearchListener, CurrencyListener {
	private ClientView view;
	private ClientModel model;
	private Timer timer;
	private static int interval = 60000;
	private ArrayList<Observer> observers = new ArrayList<>();
	private ServerSocket servSock;
	private Socket sock;
	private BufferedReader input;
	private PrintWriter output;

	public ClientController(ClientView view, ClientModel model) {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
		    public void run() {
		    	System.out.println("Calling onClose()");
		    	onClose();
		    	System.out.println("onClose() returned");
		    }
		}));
		this.view = view;
		this.model = model;
		
		try {
			sock = new Socket("127.0.0.1", 2004);
			System.out.println(sock);
			input = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			output = new PrintWriter(new BufferedWriter(new OutputStreamWriter(sock.getOutputStream())), true);
			output.println("1_" + Inet4Address.getLocalHost().getHostAddress() + "_0_0_0_0_0_0_0");
			System.out.flush();		
			
		} catch (UnknownHostException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	public void onClose() {
		try {
			output.println("2_" + Inet4Address.getLocalHost().getHostAddress() + "_0_0_0_0_0_0_0");
			System.out.flush();
			input.close();
			output.close();
			sock.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	public void run(CurrencySearchFormEvent event) {
		try {
			String s = "3_" + Inet4Address.getLocalHost().getHostAddress() + "_" + event.getT1()+"+"+event.getT2() + "_" + event.getDate1() + "_" + event.getDate2() + "_" + event.getCurrency() + "_0_0_0";
			output.println(s);
			System.out.flush();
			
			s = input.readLine();
			System.out.println("Server>" + s);
			parser(s);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void parser(String s) {
		String[] tmp = s.split("_");
		
		if (tmp[0].equals("4")) {
			model.getStock1().setCurrPrice(Double.parseDouble(tmp[6].split(",")[0]));
			model.getStock2().setCurrPrice(Double.parseDouble(tmp[6].split(",")[1]));
		}else {
			model.parseData(tmp[8]);
		}
	}
	
	private void compareStocks(Stock s1, Stock s2) {
		String s = "";
		try {
			for (int i = 0; i < s1.getSize(); i++) {
				String cl1 = String.format("%.2f", s1.getCloneClose(i));
				String cl2 = String.format("%.2f", s2.getCloneClose(i));
				s += s1.getDate(i) + " stock: " + s1.getTicker() + " close: " + cl1 + " stock: " + s2.getTicker()
						+ " close: " + cl2 + "\n";
			}
		} catch (IndexOutOfBoundsException e) {
			JOptionPane.showMessageDialog(null,
					"Datumet är för gammalt, försök med ett nyare!", "För gammalt datum", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		view.setText(s);
		view.drawGraph();
	}

	private void updateStocks(Stock s1, Stock s2, Currency curr) {
		for (int i = 0; i < s1.getSize(); i++) {
			s1.setClose(i, curr.getClose(i));
			s2.setClose(i, curr.getClose(i));
		}
	}

	@Override
	public void searchPerformed(CurrencySearchFormEvent event) {
		String t1 = event.getT1();
		String t2 = event.getT2();
		String d1 = event.getDate1();
		String d2 = event.getDate2();
		
		model.setStocks(t1, t2, d1, d2);
		
		run(event);
		
		if (!checkDate(d1, d2)) {
			model.getStock1().setData();
			model.getStock2().setData();
		}else {
			model.getStock1().setMinuteData();
			model.getStock2().setMinuteData();
		}

		compareStocks(model.getStock1(), model.getStock2());
		correlation();
	}
	
	private boolean checkDate(String date1, String date2) {
		if (date1.compareTo(date2) == 0) {
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			Date date = new Date();
			return date1.compareTo(dateFormat.format(date)) == 0;
		}else return false;
	}

	@Override
	public void currencySwitch(CurrencyChangeEvent event) {
		String curr = event.getCurrency();
		String d1 = model.getStock1().getStart();
		String d2 = model.getStock1().getEnd();
		
		model.setCurrency(curr, d1, d2, model.getStock1().getSize());
		
		updateStocks(model.getStock1(), model.getStock2(), model.getCurrency());
		compareStocks(model.getStock1(), model.getStock2());
	}

	public void correlation() {
		Stock s1 = model.getStock1();
		Stock s2 = model.getStock2();
		
		double sums1 = 0;
		double sums2 = 0;
		double sums1s2 = 0;
		double sums12 = 0;
		double sums22 = 0;
		
		for (int i = 0; i < s1.getSize(); i++) {
			sums1 += s1.getCloneClose(i);
			sums2 += s2.getCloneClose(i);
			sums1s2 += s1.getCloneClose(i) * s2.getCloneClose(i);
			sums12 += Math.pow(s1.getCloneClose(i), 2);
			sums22 += Math.pow(s2.getCloneClose(i), 2);
		}
		int n = s1.getSize();
		double sum = (n*sums1s2 - sums1*sums2)/(Math.sqrt((n*sums12-sums1*sums1) * (n*sums22-sums2*sums2)));
		
		model.setCorrelation(sum);
	}
}
