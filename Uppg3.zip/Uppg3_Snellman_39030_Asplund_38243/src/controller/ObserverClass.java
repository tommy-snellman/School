package controller;

import view.Observer;

public class ObserverClass implements Observer{

	private double stock1, stock2;
	private String ip, port;
	
	public ObserverClass(String ip, String port) {
		this.ip = ip;
		this.port = port;
	}

	public ObserverClass(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}
	
	public String getIp() {
		return ip;
	}

	@Override
	public void update(double stock1, double stock2) {
		this.stock1 = stock1;
		this.stock2 = stock2;
		
	}
	
	public double getStock1() {
		return stock1;
	}
	
	public double getStock2() {
		return stock2;
	}
}
