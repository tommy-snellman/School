package view;

public interface SearchListener {

	public void searchPerformed(SearchFormEvent event);

}
