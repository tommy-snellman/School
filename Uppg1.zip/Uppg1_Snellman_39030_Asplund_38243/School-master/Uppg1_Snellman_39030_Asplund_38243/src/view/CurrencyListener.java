package view;

public interface CurrencyListener {

	public void currencySwitch(CurrencyChangeEvent event);

}
