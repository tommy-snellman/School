package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Canvas;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JButton;
import javax.swing.border.LineBorder;

import controller.Controller;
import model.Model;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.awt.Insets;
import javax.swing.JTextPane;
import javax.swing.JTextArea;


public class View extends JFrame implements ActionListener {
	
	private Model model;
	private SearchListener searchListener;
	private CurrencyListener currencyListener;
	private JTextField ticker1;
	private JTextField ticker2;
	private JTextField date1;
	private JTextField date2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextArea textArea;


	/**
	 * Create the application.
	 * @param model 
	 */
	public View(Model model) {
		this.model = model;
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		this.setTitle("57ock 15l4nd");
		this.setBounds(100, 100, 800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{434, 0};
		gridBagLayout.rowHeights = new int[]{10, 251, 0};
		gridBagLayout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JPanel searchPanel = new JPanel();
		searchPanel.setLayout(null);
		searchPanel.setForeground(Color.GRAY);
		searchPanel.setBorder(new LineBorder(Color.DARK_GRAY));
		GridBagConstraints gbc_searchPanel = new GridBagConstraints();
		gbc_searchPanel.ipady = 99;
		gbc_searchPanel.fill = GridBagConstraints.HORIZONTAL;
		gbc_searchPanel.gridx = 0;
		gbc_searchPanel.gridy = 0;
		this.getContentPane().add(searchPanel, gbc_searchPanel);
		
		JLabel ticker1Label = new JLabel("Ticker 1:");
		ticker1Label.setBounds(10, 8, 54, 14);
		searchPanel.add(ticker1Label);
		ticker1Label.setHorizontalAlignment(SwingConstants.RIGHT);
		ticker1Label.setVerticalAlignment(SwingConstants.TOP);
		
		ticker1 = new JTextField();
		ticker1.setBounds(74, 5, 86, 20);
		searchPanel.add(ticker1);
		ticker1.setColumns(10);
		
		JLabel startDateLabel = new JLabel("Start Date:");
		startDateLabel.setBounds(174, 8, 54, 14);
		searchPanel.add(startDateLabel);
		startDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		
		date1 = new JTextField();
		date1.setBounds(231, 5, 86, 20);
		searchPanel.add(date1);
		date1.setColumns(10);
		
		JLabel ticker2Label = new JLabel("Ticker 2:");
		ticker2Label.setBounds(10, 33, 54, 14);
		searchPanel.add(ticker2Label);
		ticker2Label.setHorizontalAlignment(SwingConstants.RIGHT);
		
		ticker2 = new JTextField();
		ticker2.setBounds(74, 30, 86, 20);
		searchPanel.add(ticker2);
		ticker2.setColumns(10);
		
		JLabel endDateLabel = new JLabel("End Date:");
		endDateLabel.setBounds(180, 33, 48, 14);
		searchPanel.add(endDateLabel);
		endDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		
		date2 = new JTextField();
		date2.setBounds(231, 30, 86, 20);
		searchPanel.add(date2);
		date2.setColumns(10);
		
		JButton searchButton = new JButton("Search");
		searchButton.addActionListener(this);
		searchButton.setBounds(74, 57, 86, 23);
		searchPanel.add(searchButton);
		
		JRadioButton radioSEK = new JRadioButton("SEK");
		radioSEK.setBounds(360, 25, 109, 23);
		searchPanel.add(radioSEK);
		radioSEK.addActionListener(this);
		buttonGroup.add(radioSEK);
		
		JRadioButton radioEUR = new JRadioButton("EUR");
		radioEUR.setBounds(360, 45, 109, 23);
		searchPanel.add(radioEUR);
		radioEUR.addActionListener(this);
		buttonGroup.add(radioEUR);
		
		JRadioButton radioUSD = new JRadioButton("USD");
		radioUSD.setBounds(360, 4, 109, 23);
		searchPanel.add(radioUSD);
		radioUSD.addActionListener(this);
		buttonGroup.add(radioUSD);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.anchor = GridBagConstraints.SOUTH;
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		this.getContentPane().add(tabbedPane, gbc_tabbedPane);
		
		JPanel graphPanel = new JPanel();
		graphPanel.setBackground(Color.WHITE);
		tabbedPane.addTab("Graph", null, graphPanel, null);
		GridBagLayout gbl_graphPanel = new GridBagLayout();
		gbl_graphPanel.columnWidths = new int[]{779, 0};
		gbl_graphPanel.rowHeights = new int[]{433, 0};
		gbl_graphPanel.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_graphPanel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		graphPanel.setLayout(gbl_graphPanel);
		
		JPanel tablePanel = new JPanel();
		tabbedPane.addTab("Table", null, tablePanel, null);
		GridBagLayout gbl_tablePanel = new GridBagLayout();
		gbl_tablePanel.columnWidths = new int[]{390, 0};
		gbl_tablePanel.rowHeights = new int[]{398, 0};
		gbl_tablePanel.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_tablePanel.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		tablePanel.setLayout(gbl_tablePanel);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 0;
		tablePanel.add(scrollPane, gbc_scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Search")) {
			String t1 = ticker1.getText();
			String t2 = ticker2.getText();
			String dtFrom = date1.getText();
			String dtTo = date2.getText();
			SearchFormEvent ev = new SearchFormEvent(t1, t2, dtFrom, dtTo);
			fireSearchEvent(ev);
		} else if (e.getActionCommand().equals("USD") || e.getActionCommand().equals("SEK")
				|| e.getActionCommand().equals("EUR")) {
			String curr = e.getActionCommand();
			CurrencyChangeEvent ev = new CurrencyChangeEvent(curr);
			fireCurrencyChangeEvent(ev);
		}

	}
	
	private void fireSearchEvent(SearchFormEvent ev) {
		if (searchListener != null) {
			searchListener.searchPerformed(ev);
		}
	}

	private void fireCurrencyChangeEvent(CurrencyChangeEvent ev) {
		if (currencyListener != null) {
			currencyListener.currencySwitch(ev);
		}
	}

	public void setCurrencyListener(CurrencyListener listener) {
		this.currencyListener = listener;
	}

	public void setSearchListener(SearchListener listener) {
		this.searchListener = listener;
	}
	
	public void setText(String s) {
		textArea.setText(s);
	}
}
