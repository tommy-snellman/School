package view;

public class CurrencyChangeEvent {
	private String currency;
	private String dateF;
	private String dateT;

	public CurrencyChangeEvent(String curr) {
		this.currency = curr;
	}

	public String getCurrency() {
		return this.currency;
	}
}
