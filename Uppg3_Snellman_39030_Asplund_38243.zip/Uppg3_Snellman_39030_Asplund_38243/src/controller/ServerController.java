package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import model.Currency;
import model.Model;
import model.Stock;
import view.CurrencyChangeEvent;
import view.CurrencyListener;
import view.CurrencySearchFormEvent;
import view.Observer;
import view.SearchListener;

public class ServerController implements SearchListener, CurrencyListener {
	private Model model;
	private Timer timer;
	private static int interval = 60000;
	private ArrayList<ObserverClass> observers = new ArrayList<>();
	private ServerSocket servSock;
	private Socket sock;
	private BufferedReader in;
	private PrintWriter out;
	private String password = "Programmering_3!";

	public ServerController(Model model) {
		this.model = model;
	}
	
	public void run() {
		try {
			servSock = new ServerSocket(2004, 10);
			System.out.println(Inet4Address.getLocalHost().getHostAddress());
			System.out.println(servSock);
			
			System.out.println("Wait 4 connect");
			sock = servSock.accept();
			System.out.println(sock);
			System.out.println("Connection received from " + sock.getInetAddress().getHostName() + " and accepted on " + sock.getLocalSocketAddress() + " blahaa" + sock.getOutputStream());
			
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(sock.getOutputStream())), true);
			
			while(parseStuff(in.readLine()));   // Readline is not the best to read crypted messages due to new line and carrage return characters being removed.
			
			in.close();
			out.close();
			sock.close();
			servSock.close();
			if (timer != null) timer.cancel();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	private boolean parseStuff(String s) {
		System.out.println(s + " Inside parseStuff()");
		if (s == null) return false;
		
		System.out.println("Client> " + s);
		String decrypt = Crypt.decrypt(s, password);
		System.out.println("Client> Decrypt: " + decrypt);
		System.out.println("Client> Unpadded: " + decrypt);
		String[] tmp = decrypt.split("_");
		
		if (tmp[0].equals("1")) {
			observers.add(new ObserverClass(tmp[1]));
		}else if (tmp[0].equals("2")) {
			for (ObserverClass o : observers) {
				if (o.getIp().compareTo(tmp[1].split("_")[0]) == 0) {
					observers.remove(o);
					return false;
				}
			}
		}else if (tmp[0].equals("3")) {
			createEvent(tmp);
			sendMessage(false);
		}
		return true;
		
	}
	
	private void sendMessage(boolean notify) {
		String s;
		try {
			if (notify) {
					s = "4_" + Inet4Address.getLocalHost().getHostAddress() + "_0_0_0_0_"+ observers.get(0).getStock1()+","+observers.get(0).getStock2() + "_0_0";
			}else {
					s = "5_" + Inet4Address.getLocalHost().getHostAddress() + "_0_0_0_0_0_0_" + model.getCloneStrings(); 
			}
			
			System.out.println("Server> Clear:" + s);
			String crypt = Crypt.encrypt(s, password);
			System.out.println("Server> Sending: " + crypt);
			out.println(crypt);
		}catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	private void createEvent(String[] tmp) {
		String[] tickers = tmp[2].split("\\+");
		CurrencySearchFormEvent ev = new CurrencySearchFormEvent(tickers[0], tickers[1], tmp[3], tmp[4], tmp[5]);
		searchPerformed(ev);
	}

	private void updateStocks(Stock s1, Stock s2, Currency curr) {
		for (int i = 0; i < s1.getSize(); i++) {
			s1.setClose(i, curr.getClose(i));
			s2.setClose(i, curr.getClose(i));
		}
	}
	
	

	@Override
	public void searchPerformed(CurrencySearchFormEvent event) {
		String t1 = event.getT1();
		String t2 = event.getT2();
		String d1 = event.getDate1();
		String d2 = event.getDate2();
		
		model.setStocks(t1, t2, d1, d2);
		
		if (!checkDate(d1, d2)) {
			model.getStock1().fetchData();
			model.getStock2().fetchData();
		}else {
			model.getStock1().fetchMinuteData();
			model.getStock2().fetchMinuteData();
		}
		
		timer = new Timer();
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				notifyObservers();
			}

			private void notifyObservers() {
				for (Observer o : observers) {
					o.update(model.getStock1().getCurrPrice(), model.getStock2().getCurrPrice());
				}
			}
		}, 0, interval);
	}
	
	private boolean checkDate(String date1, String date2) {
		if (date1.compareTo(date2) == 0) {
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			Date date = new Date();
			return date1.compareTo(dateFormat.format(date)) == 0;
		}else return false;
	}

	@Override
	public void currencySwitch(CurrencyChangeEvent event) {
		String curr = event.getCurrency();
		String d1 = model.getStock1().getStart();
		String d2 = model.getStock1().getEnd();
		
		model.setCurrency(curr, d1, d2, model.getStock1().getSize());
		
		updateStocks(model.getStock1(), model.getStock2(), model.getCurrency());
	}
}
