package controller;

import java.nio.charset.Charset;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Crypt {
	@SuppressWarnings("finally")
	public static String encrypt(String s, String pass) {
		byte[] ciphertext = null;
		byte[] raw = pass.getBytes(Charset.forName("UTF-8"));
		if (raw.length != 16) {
			throw new IllegalArgumentException("Invalid key size.");
		}
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher;
		try {
			cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, new IvParameterSpec(new byte[16]));
			ciphertext = cipher.doFinal(s.getBytes(Charset.forName("UTF-8")));
	    	
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
		} finally {
			return new String(ciphertext);
		}
	}
	
	 @SuppressWarnings("finally")
	public static String decrypt(String s, String pass) {
		 String cleartext = null;
		 try{
			byte[] raw = pass.getBytes(Charset.forName("UTF-8"));
			if (raw.length != 16) {
				throw new IllegalArgumentException("Invalid key size.");
			}
			byte[] str = s.getBytes();
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, new IvParameterSpec(new byte[16]));
			byte[] original = cipher.doFinal(str);
			cleartext = new String (original, Charset.forName("UTF-8"));
	    	
	    } catch (GeneralSecurityException e) {
	    	e.printStackTrace();
	    } finally {
	    	return cleartext;
	    }
	 }
}
