package view;

public interface SearchListener {
	
	public void searchPerformed(CurrencySearchFormEvent ev);
		
}
