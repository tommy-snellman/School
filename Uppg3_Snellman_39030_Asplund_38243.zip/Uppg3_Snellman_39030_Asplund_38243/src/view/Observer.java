package view;

public interface Observer {
	public void update(double stock1, double stock2);
}
